%% 对种群进行非支配排序

% 输入：
% group:    种群信息

% 输出：
% group:    非支配排序后的信息
% Rank:     帕累托前沿等级

function [group,Rank] = NonDominatedSorting(group)

    Ngroup = numel(group);                 % 计算种群数量


    %% 初始化
    for i = 1:Ngroup
        group(i).DominationSet = [];       % 当前个体所能支配的个体Sp
        group(i).DominatedCount = 0;       % 能够支配当前个体的个数np
    end

    Rank{1} = [];

    %% 计算第一层前沿
    for i = 1:Ngroup                  % 索引i
        for j = i+1:Ngroup            % 索引i

            p = group(i);             % 索引i所对应的个体
            q = group(j);             % 索引j所对应的个体

            if Dominates(p,q)         % 判断p与q的支配关系，不判断非支配关系， 此处判断p是否支配q
                p.DominationSet = [p.DominationSet j];      %  针对p的操作 记录个体q所对应的索引j，记录索引与记录对应的个体是一样的
                q.DominatedCount = q.DominatedCount+1;    %  针对q的操作 因为p能支配q，索引q被p支配 所以所对应的nq加1
            end


            if Dominates(q.Cost, p.Cost)    %  与上方一样，只是更改编的方式   若q能支配p
                q.DominationSet = [q.DominationSet i];
                p.DominatedCount = p.DominatedCount+1;
            end

            group(i) = p;    % 更新数据
            group(j) = q;    % 更新数据
        end

        
        % 记录第一层前沿
        if group(i).DominatedCount == 0
            Rank{1} = [Rank{1} i];
            group(i).Rank = 1;
        end
    end




    %% 计算第二层及以后的前沿

    k = 1;

    while true

        Q = [];

        for i = Rank{k}           % 第一层前沿索引
            p = group(i);         % 第一层前沿所对应的种群个体

            for j = p.DominationSet         % 个体p所对应的Sp
                q = group(j);               % 个体p所支配的个体集合

                q.DominatedCount = q.DominatedCount-1;   
                % 因为个体p支配个体q，所以当计算第二层时，将能够支配个体q的个体数-1，即去除第一层后，能够支配个体q的个数


                if q.DominatedCount == 0    % 若能够支配个体q的数量为0
                    Q = [Q j]; 
                    q.Rank = k+1;
                end
                
                group(j) = q;
            end
        end
        
        if isempty(Q)
            break;
        end


        Rank{k+1} = Q;                    % 第k+1层前沿    k=1时 找的是第二层的前沿

        k = k+1;

    end
end





