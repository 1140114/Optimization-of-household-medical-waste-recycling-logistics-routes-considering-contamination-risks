%% 计算一个路线的车辆行驶距离

% 输入：
% route:         一条配送路线
% dist_matrix:    节点的距离矩阵

% 输出
% Dd:            转运车辆在完成配送时的总距离
% Dd_ps:         转运车辆在每个阶段的行驶距离

function [Dd,Dd_ps] = part_length(route,dist_matrix)
    
    n = length(route);           % 配送路线所经过的产生节点总数量
    Dd = 0;                      % 将转运车辆的初始行驶距离设为0
    Dd_ps = 0;                   % 转运车辆的初始阶段的行驶距离为0


    if n ~= 0                    % 若配送路线所经过的产生节点总数量不为0

        for i = 1:n

            if i == 1

                Dd = Dd+dist_matrix(1,route(i)+1);                  % 累计转运车辆的行驶距离
                Dd_ps = [Dd_ps,dist_matrix(1,route(i)+1)];          % 记录转运车辆各阶段的行驶距离

            else
                Dd = Dd+dist_matrix(route(i-1)+1,route(i)+1);
                Dd_ps = [Dd_ps,dist_matrix(route(i-1)+1,route(i)+1)];
            end
        end
        Dd = Dd+dist_matrix(route(end)+1,1);
        Dd_ps = [Dd_ps,dist_matrix(route(end)+1,1)];
    end
end