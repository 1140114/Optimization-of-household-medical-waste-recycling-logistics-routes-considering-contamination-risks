%% 计算每辆车完成收集后的总载货量， 以及每辆车离开当前路径上每一个产生节点时的载货量

% 输入：
% vc:             每辆转运车辆所服务的产生节点，并删除未使用的车辆
% generation:     各产生节点的家庭医疗废物产生量

% 输出：
% vl:             每辆转运车辆的最终载货量
% load_ps:        每辆转运车辆在当前路径上每个阶段的载货量


function [vl,load_ps] = vehicle_load(vc,generation)
    
    %% 初始化
    n = size(vc,1);         % 统计已派出转运车辆的数量
    vl = zeros(n,1);        % 每辆转运车辆的载重量
    load_ps = cell(n,1);    % 每辆转运车的各阶段载重量

    for i = 1:n
        route = vc{i};
        
        if isempty(route)       % 若该路线上所服务的产生节点为空
            vl(i) = 0;
            load_ps{i} = [];
        else
            [Ld,Ld_ps] = leave_load(route,generation);
            vl(i) = Ld;
            load_ps{i} = Ld_ps;
        end
    end
end