%% 计算每辆转运车辆所行驶的距离，以及每阶段的行驶距离

% 输入：
% vc：           每辆转运车辆所服务的产生节点
% dist_matrix:   各节点间的距离矩阵

% 输出：
% sumdist:       所有车辆的行驶总距离
% everydist:     每辆车辆的行驶总距离
% dist_ps:       每辆车辆的各阶段行驶距离

function [sumdist,everydist,dist_ps] = travel_distance(vc,dist_matrix)


    n = size(vc,1);             % 统计已派出车辆的数量

    %% 初始化
    everydist = zeros(n,1);     % 每辆车初始行驶总距离
    dist_ps = cell(n,1);        % 每辆车的各阶段的初始行驶距离

    for i = 1:n
        route = vc{i};
        
        if isempty(route)       % 若该路线上所服务的产生节点为空
            everydist(i) = 0;
            dist_ps{i} = [];
        else
            [Dd,Dd_ps] = part_length(route,dist_matrix);
            everydist(i) = Dd;
            dist_ps{i} = Dd_ps;
        end
    end

    sumdist = sum(everydist);               % 所有车辆行驶的总距离
