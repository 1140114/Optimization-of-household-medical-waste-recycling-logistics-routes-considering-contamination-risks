%% 令第i个个体进行觅食行为。若觅食成功，则flag为1，否则为0

% 输入：
% CK:                             使用车辆的固定费用
% CT:                             每单位的家庭医疗废物的转移成本
% COF:                            燃油单价
% PR:                             自行送往所得奖励
% non_amount_customer:            非自送---产生节点数量
% self_delivery:                  自送节点
% self_generation:                自送节点家庭医疗废物产生数量
% minK:                           最小车辆使用量
% initFish0:                      种群集合
% non_generation:                 非自送----产生节点所产生家庭医疗废物的数量
% capacity：                      车辆的载重量
% non_dist_matrix:                非自送---各节点的距离矩阵
% range:                          车辆的最大续航里程
% Velocity:                       车辆正常行驶速度
% non_V:                          非自送节点车辆实际行驶速度
% fuel_unladen:                   在正常行驶速度下，车辆空载状态下的单位距离的油耗
% fuel_fullyloaded:               在正常行驶速度下，车辆满载状态下的单位距离的油耗
% non_POP:                        非自送-两节点之间的人口总数
% non_time:                       非自送-节点间车辆实际行驶时间
% non_air_velocity：              非自送-风速信息
% gamma:                          每单位家庭医疗废物的污染率
% i:                              第i个个体

% Visual:           视野
% trynumber:        最大试探次数

% 输出：
% Xinext:           新找到的个体
% flag:             标记是否已觅食成功




function [Xinext,flag] = AF_prey(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma,i,Visual,trynumber)


    Xinext = [];
    Xi = initFish0(i,:);       % 索引i所对应的个体
    Y_init = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
    Yi = Y_init(i).Cost;
    % 个体i所对应的适应度值

    Citynumber = length(Xi);
    flag = 0;          % 标记是否觅食到更好的个体

    for j = 1:trynumber
        while(1)
            DJ = floor(rand*Visual)+1;    % 不相同的字段数

            if ( DJ>0 && DJ<=Visual )
                break;
            end

        end



        while(1)
            S(1) = floor(rand*Citynumber)+1;

            if ( S(1)>1 && S(1)<=Citynumber )     % 在所以城市里
                break
            end

        end

        p = 1;
        
        while ( p<DJ )
            t = floor(rand*Citynumber)+1;

            if ( t>1 && t<=Citynumber && sum(S == t)==0 )
                p = p+1;
                S(p) = t;
            end
        end

        Xi = initFish0(i,:);
        t = Xi(S(1));

        for k = 1:DJ-1
            Xi(S(k)) = Xi(S(k+1));
        end

        Xi(S(DJ)) = t;
        
        

        Yy = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,Xi,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
        YY =Yy(1).Cost;



        if (YY(1) < Yi(1)) && ( YY(2) < Yi(2) )
            Xinext = Xi;
            flag = 1;
            return;
        end
        
    end

    Xinext  = Xi;

end
















