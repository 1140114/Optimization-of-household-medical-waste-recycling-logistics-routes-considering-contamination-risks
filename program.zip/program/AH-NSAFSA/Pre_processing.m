%% 预处理，初步确认能使用的最少车辆

% 输入
% L:           产生节点数量
% K:           车辆数量
% generation： 产生节点所产生家庭医疗废物的量
% capacity:    车辆的载重量
% dist_matrix: 节点间的距离矩阵
% range:       车辆的最大续航里程

% 输出
% minK         车辆的最小使用量
% chrom_minK   车辆使用量最小时的染色体
% vc_minK      车辆使用量最小时，每辆车所服务的顾客
% load_ps:       各阶段的车辆载重量（累计）
% dist_ps:       各阶段的车辆行驶距离
% r_minK       车辆使用量最小时，判断vc_minK是否满足所有的约束条件，若满足为1，否则为0


function [minK,chrom_minK,vc_minK,load_ps,dist_ps,r_minK] = Pre_processing(L,K,generation,capacity,dist_matrix,range)


flag = 1;                        % 标记当前车辆数目是否合理
chrom_minK = zeros(1,L*K);       % 记录车辆使用量最小时的染色体

while flag==1
    for i = 1:50
        chrom = Encode(L,K);     % 编码
        [~,~,~,reasonable] = Decode(L,K,chrom,generation,capacity,dist_matrix,range);   % 判断当前解的编码是否合理
        
        if reasonable == 1
            chrom_minK = chrom;
            K = K-1;
            break
        end
    end

    if reasonable == 0
        break
    end
end

minK = K+1;        % 因为多减了一个，所以加1
[vc_minK,load_ps,dist_ps,r_minK] = Decode(L,minK,chrom_minK,generation,capacity,dist_matrix,range);

