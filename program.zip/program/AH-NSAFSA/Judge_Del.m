%% 检查最优解中是否存在元素丢失的情况

% 输入：
% vc:      最优分配方案，即每辆转运车辆所服务的产生节点
% L:       产生节点的数量

% 输出：
% DEL:     寻找到的丢失元素，若没有丢失元素则为空


function DEL = Judge_Del(vc,L)
    NV = size(vc,1);
    route = [];

    for i = 1:NV
        route = [route,vc{i}];
    end
    
    sr = sort(route);
    LEN = length(sr);

    %% 寻找丢失的元素
    INIT = 1:L;
    DEL = setxor(sr,INIT);
    % setxor(a,b)  可以得到a,b两个矩阵中不相同的元素，也交不在交集中的元素

end