%% 随机生成矩阵
% a 节点总数量
% 输出矩阵A
clear
clc


a=30;          % 节点总数

% A = rand(a);    % 随机生成(0,1)的31*31矩阵
%A = randi([50,500],a,a);           % [50,500]随机生成a*a的整数矩阵
A = rand(1,a);

% A=tril(A,-1)+triu(A',0);
% A=A-diag(diag(A));

filetitle='D:\Desktop\第一篇\程序\自送习惯偏向系数.xlsx';        %xlsx文件地址
xlswrite(filetitle,A);                              %生成文件名变化的xlsx文件