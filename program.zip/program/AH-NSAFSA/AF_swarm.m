%% 聚群行为

% 输入：
% CK:                             使用车辆的固定费用
% CT:                             每单位的家庭医疗废物的转移成本
% COF:                            燃油单价
% PR:                             自行送往所得奖励
% non_amount_customer:            非自送---产生节点数量
% self_delivery:                  自送节点
% self_generation:                自送节点家庭医疗废物产生数量
% minK:                           最小车辆使用量
% initFish0:                      种群集合
% non_generation:                 非自送----产生节点所产生家庭医疗废物的数量
% capacity：                      车辆的载重量
% non_dist_matrix:                非自送---各节点的距离矩阵
% range:                          车辆的最大续航里程
% Velocity:                       车辆正常行驶速度
% non_V:                          非自送节点车辆实际行驶速度
% fuel_unladen:                   在正常行驶速度下，车辆空载状态下的单位距离的油耗
% fuel_fullyloaded:               在正常行驶速度下，车辆满载状态下的单位距离的油耗
% non_POP:                        非自送-两节点之间的人口总数
% non_time:                       非自送-节点间车辆实际行驶时间
% non_air_velocity：              非自送-风速信息
% gamma:                          每单位家庭医疗废物的污染率
% i:                              第i个个体

% Visual:           视野
% crowding:         拥挤度因子
% trynumber:        最大试探次数

% 输出：
% Xinext:           新找到的路径
% flag              标记是否找到更好的路径，flag=0表示追尾失败，flag=1表示追尾成功





function [Xinext,flag] = AF_swarm(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma,i,Visual,crowding,trynumber)

    Xi = initFish0(i,:);               % 第i个个体
    N = size(initFish0,1);             % 种群数量
    YI = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,Xi,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
    Yi = YI(1).Cost;
    neighbork0 = k_neighborhood(initFish0,i,Visual);       % 第i个个体的邻域集合
    nf = size(neighbork0,1);                               % 个体i的邻域集合中的个体数量
    flag = 0;                                              % 标记是否聚群成功


    Xc = Center(neighbork0);                           % 个体i的邻域集合的中心"个体"

    % Xcc.Position = Xc;

    if ~isempty(Xc)
        YC = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,Xc,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
        
        Yc = YC(1).Cost;

        if ( Yc(1)<Yi(1) ) && ( ( Yc(2)<Yi(2) ) ) && ( nf/N<crowding )
            Xinext = Xc;
            flag = 1;
        else
            [Xinext,flag] = AF_prey(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma,i,Visual,trynumber);
        end

    else
        [Xinext,flag] = AF_prey(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma,i,Visual,trynumber);
    end

end


















