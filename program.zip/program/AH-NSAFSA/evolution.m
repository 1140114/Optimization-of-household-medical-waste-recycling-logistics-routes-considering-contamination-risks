%% 淘汰行为

% 输入：
% currX        种群信息

% 输出：
% M            新生成人工鱼群


function M = evolution(currX) 


    [currX,currX_Rank] = NonDominatedSorting(currX);        % 非支配排序，   需要计算Sp、np以及rank
    currX = CalcCrowdingDistance(currX,currX_Rank);         % 计算拥挤距离
    [currX,currX_Rank] = SortPopulation(currX);             % 种群排序

    Num_currX = numel(currX);

    for i = 1:Num_currX
        M(i,:) = currX(i).Position;         % 读取种群信息
    end

    x_1 = M(1,:);                   % 选取排名第一的人工鱼
    x_2 = M(2,:);                   % 选取排名第二的人工鱼
    [x_3,x_4] = OX(x_1,x_2);        % 进行交叉更新
    M(Num_currX,:) = [];            % 淘汰最差人工鱼
    M(Num_currX-1,:) = [];          % 淘汰次差人工鱼
    M = [M;x_3;x_4];                % 更新人工鱼

end
