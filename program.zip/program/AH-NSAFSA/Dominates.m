%% 判断支配关系

% 输入：
% p:       个体p
% q:       个体q

% 输出：
% b:       0-1   若为1， 则p支配q ; 否则为，p不支配q

function b = Dominates(p,q)

    if isstruct(p)              % 判断p是否为struct类型
        p = p.Cost;
    end

    if isstruct(q)
        q = q.Cost;
    end

    b = all(p <= q) && any(p < q);
    
end