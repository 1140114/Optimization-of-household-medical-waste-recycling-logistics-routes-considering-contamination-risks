%% 种群排序

% 输入:
% pop:     种群信息

% 输出：
% pop:     种群排序后的种群信息
% F:       前沿等级排序


function [pop, F] = SortPopulation(pop)

    %% 进行拥挤距离和rank的双重排序
    
    % 根据拥挤距离进行排序
    [~, CDSO] = sort([pop.CrowdingDistance], 'descend');    % 进行降序排列
    pop = pop(CDSO);

    
    % 根据等级进行排序
    [~, RSO] = sort([pop.Rank]);
    pop = pop(RSO);


    % 更新数据    更新前沿、更新索引、更新种群的排序
    Ranks = [pop.Rank];
    MaxRank = max(Ranks);
    F = cell(MaxRank, 1);
    for r = 1:MaxRank
        F{r} = find(Ranks == r);
    end

end
