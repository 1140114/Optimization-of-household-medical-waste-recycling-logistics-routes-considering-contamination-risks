%% 计算某一条路径上离开产生节点时的载货量

% 输入：
% route:         一条配送路线
% generation:    产生节点的家庭医疗废物的产生量

% 输出
% Ld:            转运车辆在完成配送时的总载重
% Ld_ps:         转运车辆在每个阶段的载重

function [Ld,Ld_ps] = leave_load(route,generation)
    
    n = length(route);           % 配送路线所经过的产生节点总数量
    Ld = 0;                      % 将转运车辆的初始装载量设为0
    Ld_ps = 0;                   % 转运车辆的初始阶段的载重为0
    if n ~= 0                    % 若配送路线所经过的产生节点总数量不为0
        for i = 1:n
            if route(i) ~= 0
                Ld = Ld+generation(route(i));      % 累计转运车辆的装载量
                Ld_ps = [Ld_ps,Ld];                % 记录转运车辆各阶段的装载量
            end
        end
    end
end

