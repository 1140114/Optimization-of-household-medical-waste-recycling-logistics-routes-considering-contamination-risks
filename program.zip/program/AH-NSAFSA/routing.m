%% 计算搜寻路径

% 输入：
% temp:                           车辆所服务的客户
% dist_matrix:                    节点间的距离
% i:                              顾客i

% 输出：
% duration:                       所行驶的距离




function duration = routing(temp,D,i)
  
  duration=0;
  temp=[temp,i];
  n=size(temp);

  if n==1
      duration=2*D(1,temp(1)+1)+duration;
  else
      duration=D(1,temp(1)+1)+duration;
      for j=2:n
          duration=D(temp(j-1)+1,temp(j)+1);
      end
      duration=D(temp(end)+1,1)+duration;
  end

end