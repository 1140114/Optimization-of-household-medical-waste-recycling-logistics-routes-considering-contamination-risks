%% 计算拥挤距离，进行同层之间的比较

% 输入：
% pop:      种群信息
% F:        帕累托前沿等级

% 输出：
% pop:      计算拥挤距离后的种群



function pop = CalcCrowdingDistance(pop, F)

    nF = numel(F);   % 计算总共有多少层
    
    for k = 1:nF     %  分别对每一层进行比较
        
        Costs = [pop(F{k}).Cost];  % 取出第k层前沿每个个体的cost值，即y值
        
        nObj = size(Costs, 1);     % 计算有几个目标  因为每一个维度（即目标）都要算一次距离
        
        n = numel(F{k});           % 计算第k层有几个个体
        
        d = zeros(n, nObj);        % 初始化
        
        for j = 1:nObj    % 针对维度j
            
            [cj, so] = sort(Costs(j, :));   % sort函数：排序函数   针对
            
            d(so(1), j) = inf;          % 排序的第一个个体的拥挤距离设为无穷

            
            for i = 2:n-1
                
                d(so(i), j) = abs(cj(i+1)-cj(i-1))/abs(cj(1)-cj(end)); 
                % 计算中间个体的拥挤距离
                % |前一个个体-后一个个体|除以第一个个体到最后一个个体的总长度
            end
            
            d(so(end), j) = inf;        % 排序的最后一个个体的拥挤距离设为无穷
            
        end
        
        
        for i = 1:n
            
            pop(F{k}(i)).CrowdingDistance = sum(d(i, :));    %  对每一个维度进行累计累计求和
            
        end
        
    end


end