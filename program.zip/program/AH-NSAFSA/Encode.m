%% 编码  对解进行编码，产生节点数为L，车辆数为K，则解的编码长度为L*K
% 解的表现形式为[1,L*K]之间的整数排序

% 输入
% L：    产生节点数
% K:     转运车辆数

% 输出
% chrom: 解的编码形式

function [chrom] = Encode(L,K)

chrom = randperm(L*K);

end