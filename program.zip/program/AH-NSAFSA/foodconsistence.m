%% 计算种群当前位置的食物浓度

% 输入：
% CK:                             使用车辆的固定费用
% CT:                             每单位的家庭医疗废物的转移成本
% COF:                            燃油单价
% PR:                             自行送往所得奖励
% non_amount_customer(L):         非自送---产生节点数量
% self_delivery:                  自送节点
% self_generation:                自送节点家庭医疗废物产生数量
% minK:                           最小车辆使用量
% initFis:                        种群
% non_generation:                 非自送----产生节点所产生家庭医疗废物的数量
% capacity：                      车辆的载重量
% non_dist_matrix:                非自送---各节点的距离矩阵
% range:                          车辆的最大续航里程
% Velocity:                       车辆正常行驶速度
% non_V:                          非自送节点车辆实际行驶速度
% fuel_unladen:                   在正常行驶速度下，车辆空载状态下的单位距离的油耗
% fuel_fullyloaded:               在正常行驶速度下，车辆满载状态下的单位距离的油耗
% non_POP:                        非自送-两节点之间的人口总数
% non_time:                       非自送-节点间车辆实际行驶时间
% non_air_velocity：              非自送-风速信息
% gamma:                          每单位家庭医疗废物的污染率



% 输出：
% cost(i):            计算适应值后的种群信息集合


function cost = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma)

% Ngroup = numel(group);                 % 计算种群数量
% for l = 1:Ngroup
%    init = initFis(i).Position;
cost.Cost = [];
fishnum = size(initFish,1);

for i = 1:fishnum
    [vc,load_ps,~,reasonable] = Decode(non_amount_customer,minK,initFish(i,:),non_generation,capacity,dist_matrix,range);
    % vc:            每辆转运车辆所服务的产生节点，并删除未使用的车辆
    % load_ps:       各阶段的车辆载重量（累计）
    % dist_ps:       各阶段的车辆行驶距离
    % reasonable:    标记所有产生节点是否都被服务。若合理为1，若不合理为0

    n = size(self_delivery,2);              % 自送节点数量

    if reasonable == 1
        %% 目标函数1：总成本最小化

        Z1 = CK.*minK;                         % 车辆使用的固定成本
        Z2 = CT.*sum(non_generation);          % 家庭医疗废物转运成本

        % 计算油耗成本，需先计算车辆行驶单位路程的实际油耗量
        % 计算车辆油耗
        
        k = size(vc,1);          % 派出车辆的数量
        for a = 1:k
            x = vc{a};           % 第i辆车所服务的产生节点
            b = load_ps{a};      % 第i辆车的载重记录
            z = size(x,2);       % 第i辆车所服务的节点数
            FC0(a) = 0;          % 油耗
            ERP(a) = 0;          % 风险

            for j = 1:z          % 分别对每个阶段进行计算

                
                if j == 1        % 当行驶至第一个节点时，相连接的前一个节点为收集中心
                    load_fen = b(j);                      % 载重
                    v_fen = non_V(1,x(j)+1);              % 速度
                    air = non_air_velocity(1,x(j)+1);     % 风速
                    pp = non_POP(1,x(j)+1);               % 人口数量
                    time = non_time(1,x(j)+1);            % 行驶时间
                else
                    load_fen = b(j);                             % 载重
                    v_fen = non_V(x(j-1)+1,x(j)+1);              % 速度
                    air = non_air_velocity(x(j-1)+1,x(j)+1);     % 风速
                    pp = non_POP(x(j-1)+1,x(j)+1);               % 人口数量
                    time = non_time(x(j-1)+1,x(j)+1);            % 行驶时间
                end

   
                    load_fen = b(j+1);                    % 载重
                    v_fen = non_V(x(j)+1,1);              % 速度
                    air = non_air_velocity(x(j)+1,1);     % 风速
                    pp = non_POP(x(j)+1,1);               % 人口数量
                    time = non_time(x(j)+1,1);            % 行驶时间


                FC_fen = (abs((Velocity-v_fen)./Velocity)+1).*((fuel_fullyloaded-fuel_unladen)./capacity.*load_fen+fuel_unladen);
                FC0(a) = FC0(a)+FC_fen;

                ERP_fen = (1-air).*load_fen.*gamma.*pp.*time;
                ERP(a) = ERP(a)+ERP_fen;
            end

        end
        FC = sum(FC0);

        Z3 = COF.*FC;                          % 油耗成本


        Z4 = PR.*sum(self_generation);         % 自送节点的奖励成本

        F1 = Z1+Z2+Z3+Z4;                      % 总成本

        %% 目标函数2：污染风险最小化

        



        F2 = sum(ERP);

        cost(i).Cost = [F1;F2];

    else
        cost(i).Cost = [inf;inf];
    end

end
    
end
