%% 找出一个个体的k邻域

% 输入：
% initFish0:   种群集合
% i：          索引i
% Visual:      视野





function neighbork = k_neighborhood(initFish0,i,Visual)
    
    neighbork = [];                      % 初始化，令初始邻域为空
    FishNum = size(initFish0,1);         % 计算种群数量
    route = initFish0(i,:);              % 第i个个体所对应的编码

    for k = 1:FishNum
        R = initFish0(k,:);           % 选出一个个体
        Dis = distance(route,R);    % 计算两个个体之间的"距离"

        if (Dis < Visual) && ( i ~= k )
            neighbork(end+1,:) = R;    % 只有"距离"小于视野时，才能成为邻域中的个体
        end
    end

end
