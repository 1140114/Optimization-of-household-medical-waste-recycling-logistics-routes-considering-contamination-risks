%% 种群初始化

% 输入：
% FishNum:            种群数量
% amount_customer:    产生节点数量
% K:                  车辆数目

% 输出:
% initPop:             初始化种群

function initPop = pop_init(FishNum,K,amount_customer)
    
    initPop = zeros(FishNum,K*amount_customer);

    for i = 1:FishNum
        initPop(i,:) = Encode(amount_customer,K);
    end
end