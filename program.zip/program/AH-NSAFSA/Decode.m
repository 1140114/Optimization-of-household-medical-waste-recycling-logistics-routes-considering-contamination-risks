%% 对染色体进行编码
% 输入：
% L:             产生节点的数量
% K:             转运车辆的数量
% chrom:         解的编码形式
% generation:    各产生节点的医疗废物产生量
% capacity:      转运车辆的承重量
% dist_matrix:   各节点间的距离矩阵
% range:         转运车辆的最大续航

% 输出
% vc:            每辆转运车辆所服务的产生节点，并删除未使用的车辆
% load_ps:       各阶段的车辆载重量（累计）
% dist_ps:       各阶段的车辆行驶距离
% reasonable:    标记所有产生节点是否都被服务。若合理为1，若不合理为0.


function [vc,load_ps,dist_ps,reasonable] = Decode(L,K,chrom,generation,capacity,dist_matrix,range)

%% 初始化
vc = cell(K,1);                 % 每辆转运车辆所服务的顾客
load_start = zeros(K,1);              % 初始转运车辆的载重均为0
duration = zeros(K,1);          % 初始转运车辆的行驶里程为0
flag = zeros(L,1);              % 标记每个产生节点均未被服务

for j = 1:K*L
    i = chrom(j)-L*floor((chrom(j)-1)/L);                         % 第j个基因位所对应的产生节点i
    m = 1+floor((chrom(j)-1)/L);                                  % 第j个基因位所对应的车辆m
    tempm = vc{m};                                                % 车辆m当前所服务的产生节点
    find0 = find(flag==0,1,'first');                              % 寻找所没有被服务的产生节点  查找flag==0的第一个索引

    if ~isempty(find0)                                            % 如果存在未被服务的产生节点

        if flag(i) == 0                                           % 如果产生节点i没有被服务
            duration(m) = routing(tempm,dist_matrix,i);

            if generation(i)+load_start(m) <= capacity && duration(m) <= range     % 若车辆载货重量小于载重 且 已行驶距离小于续航里程
                tempm = [tempm,i];            % 将产生节点i添加至转运车辆m的路径中
                flag(i) = 1;                  % 将产生节点i标记为已被服务
                load_start(m) = load_start(m)+generation(i);          % 将产生节点i的载重计入转运车辆m的载重中
                vc{m} = tempm;                % 更新转运车辆m当前所服务的产生节点
            else

                % 若车辆m不能服务产生节点i，则遍历m之后的车辆，判断是否能够服务产生节点i
                for h = m+1:K
                    temph = vc{h};               % 车辆h当前所服务的产生节点
                    duration(m) = routing(tempm,dist_matrix,i);

                    if generation(i)+load_start(h) <= capacity && duration(h) <= range  %若车辆载货重量小于载重 且 已行驶距离小于续航里程
                        temph = [temph,i];      % 将产生节点i添加至车辆h的路径中
                        flag = 1;               % 将产生节点i标记为已服务
                        load_start(h) = load_start(h)+generation(i);    % 更新车辆m的装载量
                        vc{h} = temph;
                        break
                    end
                end
            end
        end
    else
        break   % 若不存在未被服务的产生节点
    end
end


    DEL = Judge_Del(vc,L);                            % 判断是否有元素丢失
    [vl,load_ps] = vehicle_load(vc,generation);       % 计算每辆转运车辆的最终装载量，以及每个阶段的装载量
    [~,vr,dist_ps] = travel_distance(vc,dist_matrix);   % 计算每辆车所行驶的距离,以及每个阶段所行驶的距离

    find_capacity = find(vl>capacity,1,"first");     % 寻找是否存在不满足载重约束的车辆
    find_route = find(vr>range,1,"first");           % 寻找是否存在不满足续航约束的车辆
    find0 = find(flag==0,1,"first");                 % 寻找是否存在未被服务的产生节点



    %% 记录当前解是否合理，即所有的产生节点是否都被服务，是否有元素丢失，是否满足容量、续航约束的车辆
    % 若当前解合理，则记 reasonable=1，否则记 reasonable=0
    if (isempty(find0)) && (isempty(DEL)) && (isempty(find_route)) && (isempty(find_capacity))
        reasonable = 1;
    else
        reasonable = 0;
    end

end


