%% 删除重复个体

% 输入：
% merged_group：   合并后种群信息集合

% 输出：
% merged_group_de：  删除重复后的种群信息集合



function merged_group_de = del_pop(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,merged_group,non_generation,capacity,non_dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma)

    % 初始化
    merged_group_de.Position = [];               %  目标函数中的x   种群
    merged_group_de.Cost = [];                   %  目标函数中的y  适应度
    merged_group_de.Rank = [];                   %  排序等级
    merged_group_de.DominationSet = [];          %  当前个体所能支配的个体Sp
    merged_group_de.DominatedCount = [];         %  能够支配当前个体的个数np
    merged_group_de.CrowdingDistance = [];       %  拥挤距离

    Nfish = numel(merged_group);

    for i = 1:Nfish
        merged_Position(i,:) = merged_group(i).Position;
    end

    merged_del_Position = unique(merged_Position,'rows');

    merged_del_Cost = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,merged_del_Position,non_generation,capacity,non_dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);


    N_num = size(merged_del_Position,1); 

    for i = 1:N_num
         merged_group_de(i).Position = merged_del_Position(i,:);
         merged_group_de(i).Cost = merged_del_Cost(i).Cost;
    end

    [merged_group_de,Rank] = NonDominatedSorting(merged_group_de);        % 非支配排序，   需要计算Sp、np以及rank
    merged_group_de = CalcCrowdingDistance(merged_group_de,Rank);         % 计算拥挤距离
    [merged_group_de,~] = SortPopulation(merged_group_de);             % 种群排序
end
