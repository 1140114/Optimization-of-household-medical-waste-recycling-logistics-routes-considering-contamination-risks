%% 计算转运车辆的实时速度
% 输入
% congestion_matrix  ：道路拥堵系数
% Velocity  ：转运车辆正常行驶速度

% 输出
% V  ：在道路拥挤的情况下转运车辆的实际行驶速度


function V = real_time_speed(congestion_matrix,Velocity)

B = (1-congestion_matrix).*Velocity+(1-exp(congestion_matrix)./8.14).*congestion_matrix.*Velocity;
V = B-diag(diag(B));

end