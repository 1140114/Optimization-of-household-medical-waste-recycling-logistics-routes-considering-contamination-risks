%% 非支配排序的自适应人工鱼群算法
%  以人工鱼群算法为主体，引入非支配排序对多目标问题进行求解
%  自适应视野和拥挤度因子
%  精英策略

clear
clc


%% 数据读取

% 数据录入
note_data = readmatrix('节点信息.xlsx');                       % 读取节点相关信息        
congestion_matrix = readmatrix('道路拥挤系数.xlsx');           % 读取道路拥挤系数
air_velocity = readmatrix('风速.xlsx');                        % 读取风速信息
population_density = readmatrix('人口密度.xlsx');              % 读取人口密度信息
iota = readmatrix('自送习惯偏向系数.xlsx');                     % 读取各节点自送习惯偏向系数   

% 节点参数设定
generation = note_data(2:end,4);                              % 各家庭医疗废物产生节点的医疗废物产生量
coordinate = note_data(:,2:3);                                % 所有节点的坐标
coordinate_customer = coordinate(2:end,:);                    % 所有家庭医疗废物产生节点的坐标
amount_customer = size(coordinate_customer,1);                % 家庭医疗废物产生节点数量

% 转运车辆参数设定
K = 8;                                                        % 转运车辆数目
capacity = 100;                                               % 转运车辆载重
range = 700;                                                  % 转运车辆续航里程
Velocity = 20;                                                % 转运车辆正常行驶速度
dist = pdist(coordinate);                                     % 计算各节点之间的距离
dist_matrix = squareform(dist);                               % 将节点间的距离转换为距离矩阵
V = real_time_speed(congestion_matrix,Velocity);              % 计算转运车辆实际行驶速度
time = dist_matrix./V;                                        % 计算各节点之间的实际行驶时间

% 成本参数设定
CK = 50;                                                      % 转运车辆收集家庭医疗废物时的固定使用成本
CT = 1;                                                       % 每转移一单位家庭医疗废物所需的转移成本
COF = 0.12;                                                   % 每升柴油的价格
PR = 2;                                                       % 节点自行送往收集中心时，每单位家庭医疗废物所给的奖励

% 油耗参数
fuel_unladen = 10;                                            % 在正常行驶速度下，车辆空载状态下的单位距离的油耗
fuel_fullyloaded = 20;                                        % 在正常行驶速度下，车辆满载状态下的单位距离的油耗

% 污染风险参数
gamma = 0.3;                                                  % 每单位家庭医疗废物的污染率
POP = population_density.*dist_matrix;                        % 两节点之间的人口总数

% 自送判定
omega = 0.7;                                                  % 自送效用阈值，当自送效用指标超过该值时自行送往
dist_max = max(dist_matrix(1,2:end));                         % 节点间最大距离
dist_min = min(dist_matrix(1,2:end));                         % 节点间最小距离
generation_max = max(generation);                             % 节点间家庭医疗废物最大产生量
generation_min = min(generation);                             % 节点间家庭医疗废物最小产生量




%% 算法参数设定
FishNum = 125;                                                % 种群数量
Max_gen = 200;                                                % 最大迭代次数
trynumber = 500;                                              % 最大试探次数
% 视野
Visual0 = 65;                                                % 初始视野
Visual_min = 8;                                              % 最小视野
% 拥挤度因子
crowding0 = 1;                                                % 初始拥挤度因子
% crowding_min = 0.382;                                         % 最小拥挤度因子




%% 判断产生节点是否自行送往收集中心
beta = zeros(1,size(iota,2));
self_delivery = [];
self_generation = [];
for j = 1:30
    beta(j) = iota(j).*((dist_max-dist_matrix(1,j))./(dist_max-dist_min))+(1-iota(j)).*((generation(j)-generation_min)./(generation_max-generation_min));
    % 计算节点自送效用指标
    
    if beta(j)>0.7
        self_delivery = [self_delivery,j];   % 自送节点
        self_generation = [self_generation,generation(j)];  % 自送节点家庭医疗废物产生数量
    end
end


%% 需准运车辆配送相关节点信息

n = size(self_delivery,2);                          % 自送节点个数

non_note_data = note_data;
non_congestion_matrix = congestion_matrix;
non_air_velocity = air_velocity;
non_population_density = population_density;

i=0;
% 更新非自送节点相关信息矩阵
for j = 1:n
    k = self_delivery(j);
    non_note_data(k+1-i,:) = [];                         % 非自送节点信息
    non_congestion_matrix(k+1-i,:) = [];
    non_congestion_matrix(:,k+1-i) = [];                 % 非自送-道路拥挤系数
    non_air_velocity(k+1-i,:) = [];
    non_air_velocity(:,k+1-i) = [];                      % 非自送-风速信息
    non_population_density(k+1-i,:) = [];
    non_population_density(:,k+1-i) = [];                % 非自送-人口密度
    i = i+1;
end

% 计算非自送节点相关数据
non_generation = non_note_data(2:end,4);                       % 非自送-家庭医疗废物产生节点的医疗废物产量
non_coordinate = non_note_data(:,2:3);                         % 非自送-节点坐标
non_coordinate_customer = non_coordinate(2:end,:);             % 非自送-产生节点坐标
non_amount_customer = size(non_coordinate_customer,1);         % 非自送-产生节点数量
non_dist = pdist(non_coordinate);                              % 非自送-各节点之间的距离
non_dist_matrix = squareform(non_dist);                        % 非自送-节点间的距离矩阵
non_V = real_time_speed(non_congestion_matrix,Velocity);       % 非自送-节点间车辆实际行驶速度
non_time = non_dist_matrix./non_V;                             % 非自送-节点间车辆实际行驶时间
non_POP = non_population_density.*non_dist_matrix;             % 非自送-两节点之间的人口总数




%% 开始计算时间
tic




%% 数据预处理，初步确认能使用的最少车辆数

% 输出：
% 车辆的最小使用量 ； 车辆使用量最小时的染色体 ； 每辆车所服务的顾客 ；
% 各阶段的车辆载重量（累计） ；各阶段的车辆行驶距离 ； 判断vc_minK是否满足所有的约束条件，若满足为1，否则为0

[minK,chrom_minK,vc_minK,load_ps,dist_ps,r_minK] = Pre_processing(non_amount_customer,K,non_generation,capacity,non_dist_matrix,range);





%% 种群初始化，每一行代表着一个个体
initFish = pop_init(FishNum,minK,non_amount_customer);






%% 初始化定义

empty_individual.Position = [];               %  目标函数中的x  种群
empty_individual.Cost = [];                   %  目标函数中的y  适应度
empty_individual.Rank = [];                   %  排序等级
empty_individual.DominationSet = [];          %  当前个体所能支配的个体Sp
empty_individual.DominatedCount = [];         %  能够支配当前个体的个数np
empty_individual.CrowdingDistance = [];       %  拥挤距离

group = repmat(empty_individual,FishNum,1);   % 复制FishNum份empty_individual,进行记录pareto信息



%% 计算人工鱼群的适应度值
% for i = 1:FishNum
%     group(i).Position = initFish(i,:);
% 
% end
Cost = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish,non_generation,capacity,non_dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);

for i = 1:FishNum
    group(i).Position = initFish(i,:);
    group(i).Cost = Cost(i).Cost;
end




%% 非支配排序 + 拥挤度距离计算 + 种群排序

[group,Rank] = NonDominatedSorting(group);        % 非支配排序，   需要计算Sp、np以及rank

group = CalcCrowdingDistance(group,Rank);         % 计算拥挤距离

[group,Rank] = SortPopulation(group);             % 种群排序





%% 算法主体
gen = 1;
while gen <= Max_gen
    
    % 自适应视野、拥挤度因子设置
    Visual = floor(nthroot(exp(-gen^4/Max_gen^3),Max_gen-gen+1)*Visual0+(1-nthroot(exp(-gen^4/Max_gen^3),Max_gen-gen+1))*Visual_min);
    crowding = nthroot(exp(-gen^4/Max_gen^3),Max_gen-gen+1)*crowding0;

    % % 非自适应
    % Visual = Visual0;
    % crowding = crowding0;

    for i = 1:FishNum
        initFish0(i,:) = group(i).Position;      % 提取group中的个体信息
    end
    
    clear currX;

    currX.Position = [];               %  目标函数中的x   种群
    currX.Cost = [];                   %  目标函数中的y  适应度
    currX.Rank = [];                   %  排序等级
    currX.DominationSet = [];          %  当前个体所能支配的个体Sp
    currX.DominatedCount = [];         %  能够支配当前个体的个数np
    currX.CrowdingDistance = [];       %  拥挤距离


    % 算法迭代
    
    for i = 1:FishNum

        % 种群的移动策略
        [Xinext,flag] = movestrategy(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,initFish0,non_generation,capacity,dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma,i,Visual,crowding,trynumber);
        currX(i).Position = Xinext;
        Y(i) = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,Xinext,non_generation,capacity,non_dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
        currX(i).Cost = Y(i).Cost;
    end
    
    [currX,currX_Rank] = NonDominatedSorting(currX);        % 非支配排序，   需要计算Sp、np以及rank
    currX = CalcCrowdingDistance(currX,currX_Rank);         % 计算拥挤距离
    [currX,currX_Rank] = SortPopulation(currX);             % 种群排序


    % % 精英策略
    % Con_pop = [group
    %     currX'];           % 整合种群
    % 
    % 
    % [Con_pop,Con_pop_Rank] = NonDominatedSorting(Con_pop);        % 非支配排序，   需要计算Sp、np以及rank
    % Con_pop = CalcCrowdingDistance(Con_pop,Con_pop_Rank);         % 计算拥挤距离
    % [Con_pop,Con_pop_Rank] = SortPopulation(Con_pop);             % 种群排序
    % 
    % 
    % Con_pop = Con_pop(1:FishNum);
    % 
    % [Con_pop,Con_pop_Rank] = NonDominatedSorting(Con_pop);        % 非支配排序，   需要计算Sp、np以及rank
    % Con_pop = CalcCrowdingDistance(Con_pop,Con_pop_Rank);         % 计算拥挤距离
    % [Con_pop,Con_pop_Rank] = SortPopulation(Con_pop);             % 种群排序
    % 
    % group = Con_pop;

    % 淘汰行为


    if mod(gen,20) == 0 && gen>100 && gen<180

        M = evolution(currX);       % 淘汰较差 
        M_Y = foodconsistence(CK,CT,COF,PR,non_amount_customer,self_delivery,self_generation,minK,M,non_generation,capacity,non_dist_matrix,range,Velocity,non_V,fuel_unladen,fuel_fullyloaded,non_POP,non_time,non_air_velocity,gamma);
        Num_M = size(M,1);
        for k=1:Num_M
            M_group(k).Position = M(k,:);
            M_group(k).Cost = M_Y(k).Cost;
        end

        [M_group,M_group_Rank] = NonDominatedSorting(M_group);        % 非支配排序，   需要计算Sp、np以及rank
        M_group = CalcCrowdingDistance(M_group,M_group_Rank);         % 计算拥挤距离
        [M_group,M_group_Rank] = SortPopulation(M_group);             % 种群排序



         % group = currX;
        currX = M_group;

    end

    group = currX;
    





    % 记录每一代最优解
    best(gen) = group(1);

    % 存储F1   Pareto前沿  Rank=1
    F1 = group(Rank{1});


    % 绘制F1的结果
    figure(1);
    PlotCosts(F1);
    pause(0.01);

    
    % 显示迭代信息
    disp(['迭代次数：',num2str(gen) ': 帕累托前沿数量 = ' num2str(numel(F1))])
    gen = gen+1;

end



toc









%% 结果输出

Nbest = numel(best);
    for i = 1:Max_gen
        best_solution(i,:) = best(i).Cost;      % 提取group中的个体信息
    end
    
vc = F1.Position;
[fvc,~,~,reasonable] = Decode(non_amount_customer,minK,vc,non_generation,capacity,non_dist_matrix,range);
fvc(cellfun(@isempty,fvc))=[];


besty = F1.Cost;
disp(['最优值：','目标函数1:',num2str(besty(1,:)),';','目标函数2:',num2str(besty(2,:))]);

a = numel(F1);
disp(['帕累托前沿非支配解的个数：',num2str(a)]);
for i=1:a
    b = F1(i).Cost;
    disp(['帕累托前沿第',num2str(i),'个非支配解为：',num2str(b(1,:)),',',num2str(b(2,:))]);
end


% 自送节点信息
Nself = size(self_delivery,2);
% disp(['目标函数1',num2str(besty(1,:))]);
disp(['自行送至收集中心的产生节点：',num2str(self_delivery(:,1)),'、',num2str(self_delivery(:,2)),'、',num2str(self_delivery(:,3)),'、',num2str(self_delivery(:,4))]);




%% 迭代图等绘制

% 算法迭代图
figure;
plot(1:Nbest, best_solution(:,1)', 'b'); % 绘制第一个目标函数的最优值
xlabel('Generation');
ylabel('Objective Value');
title('Convergence plot for Objective 1');

figure;
plot(1:Nbest, best_solution(:,2)', 'r'); % 绘制第二个目标函数的最优值
xlabel('Generation');
ylabel('Objective Value');
title('Convergence plot for Objective 2');


% 车辆路径图
draw_Best(fvc,non_coordinate);








